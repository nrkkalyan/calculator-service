package com.example.calculatorservice.api.functionaltests;


import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.util.FileSystemUtils;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.example.calculatorservice.CalculatorServiceApplication;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import lombok.extern.slf4j.Slf4j;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CalculatorServiceApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public abstract class BasicTest extends AbstractTestNGSpringContextTests {

    private static final AtomicLong counter = new AtomicLong();

    protected String baseUrl;

    protected static String logTraceId;

    @Autowired
    private Environment environment;

    @BeforeClass
    @Parameters({"baseUrl"})
    public void beforeTest(@Optional("http://127.0.0.1:5050") final String baseUrl) throws Exception {
        logTraceId = generateRandomUniqueString();
        FileSystemUtils.deleteRecursively(new File("logs"));
        FileSystemUtils.deleteRecursively(new File("test-results"));
        FileSystemUtils.deleteRecursively(new File("test-output"));
        log("@BeforeClass Started TestNG Functional Test executed under logTraceId: %s", logTraceId);
        this.baseUrl = "http://127.0.0.1:" + environment.getProperty("local.server.port");
        RestAssured.reset();
        logger.info(this.baseUrl);
    }

    @AfterClass
    public void release() {
        log.info("@AfterClass Completed TestNG Functional Test executed under logTraceId: {}", logTraceId);
        logTraceId = null;
    }

    protected void log(final String paramString, final Object... argurments) {
        final String formatedString = argurments != null && argurments.length > 0 ? String.format(paramString, argurments) : paramString;
        LoggerFactory.getLogger(getClass()).info(formatedString);
        Reporter.log(formatedString.replaceAll("\n", "<br>"));
    }

    public static String generateRandomUniqueString() {
        return String.valueOf(System.nanoTime() + counter.incrementAndGet());
    }

    public static long generateRandomUniqueNumber() {
        return Long.valueOf(generateRandomUniqueString());
    }

    public Response createResource(String resourceBody, String resource){
        return restAssuredClient()
                .given()
                .contentType(ContentType.JSON)
                .body(resourceBody)
                .post(baseUrl + resource);
    }

    protected RequestSpecification restAssuredClient() {
        final Map<String, String> headers = new ConcurrentHashMap<>();
        return RestAssured.given().headers(headers);
    }


    protected String getLogTraceId() {
        if (org.apache.commons.lang3.StringUtils.isBlank(logTraceId)) {
            logTraceId = generateRandomUniqueString();
        }
        log("Running: %s with logTraceId: %s", getClass().getSimpleName(), logTraceId);
        log.info("Running:{} with logTraceId: {}", getClass().getSimpleName(), logTraceId);
        return logTraceId;
    }

    @BeforeMethod
    public void before() {
        log.info("Started TestNG Functional Test method with logTraceId: {}", logTraceId);
    }

    @AfterMethod
    public void after() {
        log.info("Completed TestNG Functional Test method with logTraceId: {}", logTraceId);
    }

}
