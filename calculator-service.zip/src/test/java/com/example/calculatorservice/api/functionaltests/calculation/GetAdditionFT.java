package com.example.calculatorservice.api.functionaltests.calculation;

import java.math.BigDecimal;

import org.assertj.core.api.Assertions;
import org.testng.annotations.Test;

import com.example.calculatorservice.api.functionaltests.BasicTest;

import io.restassured.http.ContentType;
import io.restassured.response.ExtractableResponse;
import io.restassured.response.Response;

@Test
public class GetAdditionFT extends BasicTest {
    /**
     * Get addition
     */
    public void getAddition() {
        ExtractableResponse<Response> response = restAssuredClient().when()
                .get(baseUrl + "/calculate/sum?x=5&y=71")
                .then()
                .assertThat()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .extract();
        BigDecimal result = response.as(BigDecimal.class);
        Assertions.assertThat(result).isEqualTo(new BigDecimal("76"));
    }

}
