package com.example.calculatorservice.controller;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("calculate")
public class CalculationController {

	@GetMapping(path="sum")
	public BigDecimal sum(@NotNull @RequestParam("x") BigDecimal x, @NotNull @RequestParam("y") BigDecimal y){
		return x.add(y);
	}
	
	@GetMapping("ping")
	public String ping() {
		return "pong";
	}
}
